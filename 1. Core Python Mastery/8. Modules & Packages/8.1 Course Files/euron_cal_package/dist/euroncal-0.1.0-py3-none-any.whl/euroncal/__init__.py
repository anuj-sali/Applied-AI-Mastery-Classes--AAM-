from .calculator import add, subtract, multiply, divide, power, square_root, main

__version__ = "0.1.0"